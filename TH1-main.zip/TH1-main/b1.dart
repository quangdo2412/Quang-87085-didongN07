void main(){
  print("dart");
}