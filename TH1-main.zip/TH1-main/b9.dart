void main() {
  String name = "do van quang";
print(name.replaceAll(' ', ''));
}