void main() {
  int a = 4;
  int  b = 6;
  int temp = a;
  a=b;
  b=temp;
  print("a = $a");
  print("b = $b");
}