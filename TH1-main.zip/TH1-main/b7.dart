void main(){
  var a = 24;
  var b = 12;
  var thuong = a/b;
  var sodu = a%b;
  print("Thuong cua hai so la $thuong");
  print("Phan du cua hai so la $sodu");
}