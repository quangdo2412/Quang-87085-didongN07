void main(){
  print('Hello I am “John Doe”');
  print("Hello I’am “John Doe”");
}